import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tankbeurt-list-page',
  templateUrl: './tankbeurt-list-page.component.html',
  styleUrls: ['./tankbeurt-list-page.component.css']
})
export class TankbeurtListPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
