export interface Admin{
    role:boolean;
}