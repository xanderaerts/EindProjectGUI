export class TankBeurt {
    constructor(
    public id:string,
    public date:string,
    public totLiters:number,
    public totPrice:number,
    public kmStand:number
    ){}

}