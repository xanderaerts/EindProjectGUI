// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
  
    firebase: {

      apiKey: "AIzaSyCizP77Oo5GoLfjcOxP22tJpX595QAOtTc",
    
      authDomain: "tankcounter-54d6c.firebaseapp.com",
    
      projectId: "tankcounter-54d6c",
    
      storageBucket: "tankcounter-54d6c.appspot.com",
    
      messagingSenderId: "931581716582",
    
      appId: "1:931581716582:web:ff02a0a0c362f0398665a7",
    
      measurementId: "G-96L0B4GSWL"
    
    }
  
  };
  
  /*
   * For easier debugging in development mode, you can import the following file
   * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
   *
   * This import should be commented out in production mode because it will have a negative impact
   * on performance if an error is thrown.
   */
  // import 'zone.js/plugins/zone-error';  // Included with Angular CLI.