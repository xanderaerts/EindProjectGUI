export const environment = {
    production: true,
    firebase:{
  
      apiKey: "AIzaSyCizP77Oo5GoLfjcOxP22tJpX595QAOtTc",
    
      authDomain: "tankcounter-54d6c.firebaseapp.com",
    
      projectId: "tankcounter-54d6c",
    
      storageBucket: "tankcounter-54d6c.appspot.com",
    
      messagingSenderId: "931581716582",
    
      appId: "1:931581716582:web:5285deebbfb342958665a7",
    
      measurementId: "G-KBJLERFSD0"
    
    }
  };