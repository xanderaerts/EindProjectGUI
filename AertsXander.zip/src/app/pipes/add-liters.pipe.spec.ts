import { AddLitersPipe } from './add-liters.pipe';

describe('AddLitersPipe', () => {
  it('create an instance', () => {
    const pipe = new AddLitersPipe();
    expect(pipe).toBeTruthy();
  });
});
