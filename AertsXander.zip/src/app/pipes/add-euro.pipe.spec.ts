import { AddEuroPipe } from './add-euro.pipe';

describe('AddEuroPipe', () => {
  it('create an instance', () => {
    const pipe = new AddEuroPipe();
    expect(pipe).toBeTruthy();
  });
});
