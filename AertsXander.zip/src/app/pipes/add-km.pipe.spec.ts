import { AddKmPipe } from './add-km.pipe';

describe('AddKmPipe', () => {
  it('create an instance', () => {
    const pipe = new AddKmPipe();
    expect(pipe).toBeTruthy();
  });
});
