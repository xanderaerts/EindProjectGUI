export class tankBeurt {
    constructor(
    public id: number,
    public date:string,
    public totLiters:number,
    public totPrice:number,
    public kmStand:number
    ){}

}